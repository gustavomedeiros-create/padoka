Site Padoka — versão comercial aperfeiçoada.
Abra index.html para visualizar. Publique o index.html junto à pasta assets.
As fotografias são referências externas hospedadas no Unsplash; substitua por fotos reais autorizadas antes de publicar.
O formulário abre o WhatsApp com mensagem pronta, sem armazenamento de dados.
Clientes atuais conforme informações fornecidas pela Padoka.
